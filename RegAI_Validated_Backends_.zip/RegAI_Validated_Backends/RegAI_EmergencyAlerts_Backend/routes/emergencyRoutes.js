const express = require('express');
const router = express.Router();
const EmergencyAlert = require('../models/EmergencyAlert');

router.post('/', async (req, res) => {
  try {
    const alert = new EmergencyAlert(req.body);
    await alert.save();
    res.status(201).send(alert);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.get('/', async (req, res) => {
  try {
    const alerts = await EmergencyAlert.find().sort({ timestamp: -1 });
    res.send(alerts);
  } catch (err) {
    res.status(500).send(err);
  }
});

module.exports = router;
