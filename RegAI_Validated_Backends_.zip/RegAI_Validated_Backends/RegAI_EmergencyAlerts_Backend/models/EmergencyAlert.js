const mongoose = require('mongoose');

const emergencyAlertSchema = new mongoose.Schema({
  type: String,
  message: String,
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model('EmergencyAlert', emergencyAlertSchema);
