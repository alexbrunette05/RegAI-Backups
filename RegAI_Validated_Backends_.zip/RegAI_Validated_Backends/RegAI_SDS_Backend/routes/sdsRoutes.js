const express = require('express');
const router = express.Router();
const SDS = require('../models/SDS');

// Create new SDS entry
router.post('/', async (req, res) => {
  try {
    const sds = new SDS(req.body);
    const saved = await sds.save();
    res.status(201).json(saved);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Get all SDS entries
router.get('/', async (req, res) => {
  try {
    const list = await SDS.find();
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Search SDS by chemical name
router.get('/search', async (req, res) => {
  try {
    const name = req.query.name || '';
    const result = await SDS.find({ chemicalName: { $regex: name, $options: 'i' } });
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
