const mongoose = require('mongoose');

const SDSchema = new mongoose.Schema({
  chemicalName: String,
  casNumber: String,
  hazardClass: String,
  signalWord: String,
  manufacturer: String,
  documentURL: String,
  lastUpdated: Date,
  regionBans: [String]
});

module.exports = mongoose.model('SDS', SDSchema);
