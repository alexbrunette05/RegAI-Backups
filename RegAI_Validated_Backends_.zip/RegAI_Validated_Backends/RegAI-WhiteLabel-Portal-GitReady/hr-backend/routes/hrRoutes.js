const express = require('express');
const router = express.Router();
const HrController = require('../controllers/hrController');

// Basic employee creation and listing
router.post('/employees', HrController.createEmployee);
router.get('/employees', HrController.getAllEmployees);

module.exports = router;
