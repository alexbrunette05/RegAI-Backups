
const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  position: String,
  startDate: Date,
  documents: [String],
  trainingCompleted: Boolean,
  timeOffRequests: [{
    type: { type: String },
    startDate: Date,
    endDate: Date,
    status: { type: String, enum: ['pending', 'approved', 'denied'], default: 'pending' }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Employee', employeeSchema);
