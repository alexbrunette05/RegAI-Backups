
const express = require('express');
const router = express.Router();
const hrController = require('../controllers/hrController');

// Create a new employee record
router.post('/employees', hrController.createEmployee);

// Get all employee records
router.get('/employees', hrController.getAllEmployees);

// Get a specific employee by ID
router.get('/employees/:id', hrController.getEmployeeById);

// Update a specific employee by ID
router.put('/employees/:id', hrController.updateEmployee);

// Delete a specific employee by ID
router.delete('/employees/:id', hrController.deleteEmployee);

module.exports = router;

