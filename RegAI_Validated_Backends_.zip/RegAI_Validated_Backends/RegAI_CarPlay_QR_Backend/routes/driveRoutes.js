const express = require('express');
const router = express.Router();
const driveController = require('../controllers/driveController');

router.post('/start', driveController.startDrive);
router.post('/end/:id', driveController.endDrive);
router.post('/gps/:id', driveController.addGPS);

module.exports = router;
