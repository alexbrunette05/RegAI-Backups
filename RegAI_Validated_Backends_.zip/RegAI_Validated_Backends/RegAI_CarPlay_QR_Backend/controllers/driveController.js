const DriveSession = require('../models/DriveSession');

exports.startDrive = async (req, res) => {
  try {
    const session = new DriveSession({
      driverId: req.body.driverId,
      startTime: new Date()
    });
    await session.save();
    res.status(201).json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.endDrive = async (req, res) => {
  try {
    const session = await DriveSession.findById(req.params.id);
    session.endTime = new Date();
    session.active = false;
    await session.save();
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.addGPS = async (req, res) => {
  try {
    const session = await DriveSession.findById(req.params.id);
    session.gpsBreadcrumbs.push({
      lat: req.body.lat,
      lng: req.body.lng,
      timestamp: new Date()
    });
    await session.save();
    res.status(200).json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
