const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB error:', err));

// Routes
app.use('/api/drive', require('./routes/driveRoutes'));

// Start server
const PORT = process.env.PORT || 5002;
app.listen(PORT, () => {
  console.log(`CarPlay Backend Running on port ${PORT}`);
});
