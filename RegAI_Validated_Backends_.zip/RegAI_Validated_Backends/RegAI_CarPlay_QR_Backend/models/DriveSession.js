const mongoose = require('mongoose');

const DriveSessionSchema = new mongoose.Schema({
  driverId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  startTime: { type: Date, required: true },
  endTime: { type: Date },
  gpsBreadcrumbs: [{ lat: Number, lng: Number, timestamp: Date }],
  active: { type: Boolean, default: true }
});

module.exports = mongoose.model('DriveSession', DriveSessionSchema);
