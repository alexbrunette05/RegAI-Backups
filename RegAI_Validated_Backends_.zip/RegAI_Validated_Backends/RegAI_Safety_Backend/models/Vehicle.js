const mongoose = require('mongoose');

const VehicleSchema = new mongoose.Schema({
  vin: String,
  plateNumber: String,
  registrationDue: Date,
  iftaDue: Date,
  hvutDue: Date,
  irpDue: Date,
  dotInspectionDue: Date,
  lastMaintenance: Date,
  status: String,
  assignedDriverId: { type: mongoose.Schema.Types.ObjectId, ref: 'Driver' }
});

module.exports = mongoose.model('Vehicle', VehicleSchema);
