const mongoose = require('mongoose');

const IncidentReportSchema = new mongoose.Schema({
  vehicleId: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle' },
  description: String,
  date: Date,
  resolved: Boolean,
  attachments: [String]
});

module.exports = mongoose.model('IncidentReport', IncidentReportSchema);
