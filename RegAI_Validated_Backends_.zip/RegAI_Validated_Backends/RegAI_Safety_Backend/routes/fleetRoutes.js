const express = require('express');
const router = express.Router();
const Vehicle = require('../models/Vehicle');
const IncidentReport = require('../models/IncidentReport');

router.post('/vehicle', async (req, res) => {
  try {
    const newVehicle = new Vehicle(req.body);
    await newVehicle.save();
    res.status(201).json(newVehicle);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/vehicles', async (req, res) => {
  try {
    const vehicles = await Vehicle.find();
    res.status(200).json(vehicles);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/incident', async (req, res) => {
  try {
    const report = new IncidentReport(req.body);
    await report.save();
    res.status(201).json(report);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/incidents/:vehicleId', async (req, res) => {
  try {
    const reports = await IncidentReport.find({ vehicleId: req.params.vehicleId });
    res.status(200).json(reports);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
