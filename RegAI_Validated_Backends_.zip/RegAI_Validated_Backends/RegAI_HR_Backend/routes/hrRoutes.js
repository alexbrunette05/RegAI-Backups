const express = require('express');
const router = express.Router();
const HRRecord = require('../models/HRRecord');

router.post('/record', async (req, res) => {
  try {
    const newRecord = new HRRecord(req.body);
    await newRecord.save();
    res.status(201).json(newRecord);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/records/:userId', async (req, res) => {
  try {
    const records = await HRRecord.find({ userId: req.params.userId });
    res.status(200).json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
