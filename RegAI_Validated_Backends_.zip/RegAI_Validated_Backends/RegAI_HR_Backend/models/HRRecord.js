const mongoose = require('mongoose');

const HRRecordSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: String, // e.g. onboarding, training, termination
  description: String,
  date: Date,
  files: [String]
});

module.exports = mongoose.model('HRRecord', HRRecordSchema);
