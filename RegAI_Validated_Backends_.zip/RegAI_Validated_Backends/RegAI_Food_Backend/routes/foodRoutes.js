const express = require('express');
const router = express.Router();
const TempLog = require('../models/TempLog');
const Allergen = require('../models/Allergen');
const RecipeBatch = require('../models/RecipeBatch');

router.post('/temp', async (req, res) => {
  try {
    const log = new TempLog(req.body);
    const saved = await log.save();
    res.status(201).json(saved);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/allergen', async (req, res) => {
  try {
    const allergen = new Allergen(req.body);
    const saved = await allergen.save();
    res.status(201).json(saved);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/batch', async (req, res) => {
  try {
    const batch = new RecipeBatch(req.body);
    const saved = await batch.save();
    res.status(201).json(saved);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/temps', async (req, res) => {
  const logs = await TempLog.find();
  res.json(logs);
});

router.get('/allergens', async (req, res) => {
  const list = await Allergen.find();
  res.json(list);
});

router.get('/batches', async (req, res) => {
  const list = await RecipeBatch.find();
  res.json(list);
});

module.exports = router;
