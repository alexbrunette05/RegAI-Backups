const mongoose = require('mongoose');
const RecipeBatchSchema = new mongoose.Schema({
  recipeName: String,
  ingredients: [String],
  quantity: Number,
  preparedBy: String,
  datePrepared: Date
});
module.exports = mongoose.model('RecipeBatch', RecipeBatchSchema);
