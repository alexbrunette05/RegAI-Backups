const mongoose = require('mongoose');
const TempLogSchema = new mongoose.Schema({
  location: String,
  temperature: Number,
  timestamp: Date,
  recordedBy: String
});
module.exports = mongoose.model('TempLog', TempLogSchema);
