const mongoose = require('mongoose');
const AllergenSchema = new mongoose.Schema({
  name: String,
  ingredients: [String],
  riskLevel: String
});
module.exports = mongoose.model('Allergen', AllergenSchema);
